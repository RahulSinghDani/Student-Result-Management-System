AmCharts.translations.dataLoader.lt = {
  'Error loading the file': 'Nepavyko užkrauti failo',
  'Error parsing JSON file': 'Skaitant JSON failą įvyko klaida',
  'Unsupported data format': 'Nepalaikomas duomenų formatas',
  'Loading data...': 'Kraunami duomenys...'
}